JSON to Excel Converter - v3

IMPORTANT FIX:
Each response object in an array becomes ONE Excel row.

This version specifically recognizes structures such as:
{
  "data": {
    "validationResponses": [
      { ... },
      { ... },
      { ... }
    ]
  }
}

For the supplied name-enquiry style JSON, validationResponses contains 5 objects, so the Excel output will contain 5 data rows plus the header row.

It also supports a plain top-level array:
[
  { ... },
  { ... }
]

BUILD:
1. Extract this ZIP on Windows.
2. Double-click build.bat.
3. The EXE will be created at:
   publish\JsonToExcel.exe

The final EXE is self-contained and does not require Python or .NET on the target machine.
