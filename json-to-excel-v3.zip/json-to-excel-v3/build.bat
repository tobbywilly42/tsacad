@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>nul
if errorlevel 1 (
  echo .NET 8 SDK is not installed.
  echo Attempting installation via winget...
  winget install Microsoft.DotNet.SDK.8 --accept-source-agreements --accept-package-agreements
  if errorlevel 1 (
    echo.
    echo Could not install the .NET 8 SDK automatically.
    echo Please install the .NET 8 SDK from Microsoft, then run this file again.
    pause
    exit /b 1
  )
)

echo Building JSON to Excel Converter...
dotnet publish JsonToExcel.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:EnableCompressionInSingleFile=true -o publish
if errorlevel 1 (
  echo.
  echo BUILD FAILED.
  pause
  exit /b 1
)

echo.
echo BUILD SUCCESSFUL.
echo Executable: %~dp0publish\JsonToExcel.exe
pause
