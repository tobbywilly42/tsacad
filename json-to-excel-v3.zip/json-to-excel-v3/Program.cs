using System.IO.Compression;
using System.Text;
using System.Text.Json;
using System.Windows.Forms;

namespace JsonToExcel;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}

public sealed class MainForm : Form
{
    readonly TextBox fileBox = new() { Dock = DockStyle.Fill, ReadOnly = true };
    readonly Button browse = new() { Text = "Select JSON...", AutoSize = true };
    readonly Button convert = new() { Text = "Convert to Excel", AutoSize = true, Enabled = false };
    readonly Label status = new() { Text = "Select a JSON file to begin.", AutoSize = true };

    public MainForm()
    {
        Text = "JSON to Excel Converter";
        Width = 760; Height = 220;
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;

        var title = new Label { Text = "JSON → Excel", Font = new System.Drawing.Font("Segoe UI", 18, System.Drawing.FontStyle.Bold), Dock = DockStyle.Top, Height = 55, Padding = new Padding(15, 10, 0, 0) };
        var row = new TableLayoutPanel { Dock = DockStyle.Top, Height = 45, Padding = new Padding(15, 5, 15, 5), ColumnCount = 2 };
        row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        row.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        row.Controls.Add(fileBox, 0, 0); row.Controls.Add(browse, 1, 0);
        var bottom = new FlowLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(15, 10, 15, 10) };
        bottom.Controls.Add(convert); bottom.Controls.Add(status);
        Controls.Add(bottom); Controls.Add(row); Controls.Add(title);

        browse.Click += (_, _) => PickFile();
        convert.Click += (_, _) => ConvertFile();
    }

    void PickFile()
    {
        using var dlg = new OpenFileDialog { Filter = "JSON files (*.json)|*.json|All files (*.*)|*.*", Title = "Select JSON file" };
        if (dlg.ShowDialog() == DialogResult.OK)
        {
            fileBox.Text = dlg.FileName;
            convert.Enabled = true;
            status.Text = "Ready to convert.";
        }
    }

    void ConvertFile()
    {
        try
        {
            status.Text = "Reading JSON...";
            UseWaitCursor = true;
            Application.DoEvents();

            var result = JsonFlattener.Load(fileBox.Text);

            using var save = new SaveFileDialog
            {
                Filter = "Excel Workbook (*.xlsx)|*.xlsx",
                FileName = Path.GetFileNameWithoutExtension(fileBox.Text) + ".xlsx",
                Title = "Save Excel workbook"
            };
            if (save.ShowDialog() != DialogResult.OK) return;

            status.Text = $"Writing {result.Rows.Count:N0} rows...";
            Application.DoEvents();
            XlsxWriter.Write(save.FileName, result.Headers, result.Rows);
            status.Text = $"Done — {result.Rows.Count:N0} rows written.";
            MessageBox.Show($"Conversion complete.\n\nSaved to:\n{save.FileName}\n\nRows: {result.Rows.Count:N0}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            status.Text = "Conversion failed.";
            MessageBox.Show(ex.Message, "Conversion error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally { UseWaitCursor = false; }
    }
}

public sealed record ConversionResult(List<string> Headers, List<Dictionary<string, string>> Rows);

static class JsonFlattener
{
    public static ConversionResult Load(string path)
    {
        var json = File.ReadAllText(path, Encoding.UTF8);
        using var doc = JsonDocument.Parse(json);
        var root = doc.RootElement;

        // IMPORTANT: Many banking/name-enquiry responses have this structure:
        // { "data": { "validationResponses": [ { ... }, { ... }, ... ] } }
        // validationResponses is explicitly preferred so each object becomes one row.
        JsonElement? records = FindPreferredRecordArray(root);
        records ??= FindAnyObjectArray(root);

        var rows = new List<Dictionary<string, string>>();
        if (records.HasValue)
        {
            foreach (var item in records.Value.EnumerateArray())
            {
                if (item.ValueKind != JsonValueKind.Object) continue;
                var row = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                FlattenObject(item, "", row);
                rows.Add(row);
            }
        }
        else
        {
            // If there is no array of objects, a single object is one row.
            if (root.ValueKind == JsonValueKind.Object)
            {
                var row = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                FlattenObject(root, "", row);
                rows.Add(row);
            }
            else
                throw new InvalidDataException("No JSON array containing response objects was found.");
        }

        // Build a stable union of all fields so every response is represented by one row.
        var headers = new List<string>();
        foreach (var row in rows)
            foreach (var key in row.Keys)
                if (!headers.Contains(key, StringComparer.OrdinalIgnoreCase)) headers.Add(key);

        if (headers.Count == 0) headers.Add("Value");
        return new ConversionResult(headers, rows);
    }

    static JsonElement? FindPreferredRecordArray(JsonElement e)
    {
        if (e.ValueKind == JsonValueKind.Object)
        {
            // Prefer common response-array names anywhere in the document.
            string[] preferred = { "validationResponses", "responses", "results", "transactions", "records", "items", "data" };
            foreach (var name in preferred)
            {
                foreach (var p in e.EnumerateObject())
                {
                    if (string.Equals(p.Name, name, StringComparison.OrdinalIgnoreCase) && IsObjectArray(p.Value))
                        return p.Value;
                }
            }
            foreach (var p in e.EnumerateObject())
            {
                var found = FindPreferredRecordArray(p.Value);
                if (found.HasValue) return found;
            }
        }
        else if (e.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in e.EnumerateArray())
            {
                var found = FindPreferredRecordArray(item);
                if (found.HasValue) return found;
            }
        }
        return null;
    }

    static JsonElement? FindAnyObjectArray(JsonElement e)
    {
        if (e.ValueKind == JsonValueKind.Array)
        {
            if (IsObjectArray(e)) return e;
            foreach (var item in e.EnumerateArray())
            {
                var found = FindAnyObjectArray(item);
                if (found.HasValue) return found;
            }
        }
        else if (e.ValueKind == JsonValueKind.Object)
        {
            foreach (var p in e.EnumerateObject())
            {
                if (IsObjectArray(p.Value)) return p.Value;
            }
            foreach (var p in e.EnumerateObject())
            {
                var found = FindAnyObjectArray(p.Value);
                if (found.HasValue) return found;
            }
        }
        return null;
    }

    static bool IsObjectArray(JsonElement e)
    {
        if (e.ValueKind != JsonValueKind.Array) return false;
        bool any = false;
        foreach (var x in e.EnumerateArray())
        {
            any = true;
            if (x.ValueKind != JsonValueKind.Object) return false;
        }
        return any;
    }

    static void FlattenObject(JsonElement e, string prefix, Dictionary<string, string> row)
    {
        foreach (var p in e.EnumerateObject())
        {
            var key = string.IsNullOrEmpty(prefix) ? p.Name : prefix + "." + p.Name;
            FlattenValue(p.Value, key, row);
        }
    }

    static void FlattenValue(JsonElement e, string key, Dictionary<string, string> row)
    {
        switch (e.ValueKind)
        {
            case JsonValueKind.Object:
                FlattenObject(e, key, row);
                break;
            case JsonValueKind.Array:
                // Arrays inside an individual response are kept in that same row as JSON text.
                row[key] = e.GetRawText();
                break;
            case JsonValueKind.Null:
                row[key] = "";
                break;
            case JsonValueKind.True:
                row[key] = "true";
                break;
            case JsonValueKind.False:
                row[key] = "false";
                break;
            default:
                row[key] = e.ToString();
                break;
        }
    }
}

static class XlsxWriter
{
    public static void Write(string path, List<string> headers, List<Dictionary<string, string>> rows)
    {
        if (File.Exists(path)) File.Delete(path);
        using var fs = new FileStream(path, FileMode.CreateNew);
        using var zip = new ZipArchive(fs, ZipArchiveMode.Create);
        Add(zip, "[Content_Types].xml", ContentTypes());
        Add(zip, "_rels/.rels", RootRels());
        Add(zip, "xl/workbook.xml", Workbook());
        Add(zip, "xl/_rels/workbook.xml.rels", WorkbookRels());
        Add(zip, "xl/worksheets/sheet1.xml", Sheet(headers, rows));
        Add(zip, "docProps/app.xml", AppProps());
        Add(zip, "docProps/core.xml", CoreProps());
    }

    static void Add(ZipArchive z, string name, string content)
    {
        var e = z.CreateEntry(name, CompressionLevel.Fastest);
        using var w = new StreamWriter(e.Open(), new UTF8Encoding(false)); w.Write(content);
    }
    static string Esc(string s) => System.Security.SecurityElement.Escape(s) ?? "";
    static string Cell(string value, int row, int col)
    {
        string refn = Col(col) + row;
        return $"<c r=\"{refn}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">{Esc(value)}</t></is></c>";
    }
    static string Col(int n) { var s = ""; while (n > 0) { n--; s = (char)('A' + n % 26) + s; n /= 26; } return s; }
    static string Sheet(List<string> h, List<Dictionary<string, string>> rows)
    {
        var sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>");
        sb.Append("<row r=\"1\">");
        for (int c = 1; c <= h.Count; c++) sb.Append(Cell(h[c - 1], 1, c));
        sb.Append("</row>");
        for (int r = 0; r < rows.Count; r++)
        {
            sb.Append($"<row r=\"{r + 2}\">");
            for (int c = 1; c <= h.Count; c++)
            {
                rows[r].TryGetValue(h[c - 1], out var v);
                sb.Append(Cell(v ?? "", r + 2, c));
            }
            sb.Append("</row>");
        }
        sb.Append("</sheetData></worksheet>");
        return sb.ToString();
    }
    static string ContentTypes() => "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/><Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/><Override PartName=\"/docProps/app.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.extended-properties+xml\"/></Types>";
    static string RootRels() => "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>";
    static string Workbook() => "<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"Data\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>";
    static string WorkbookRels() => "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>";
    static string AppProps() => "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Properties xmlns=\"http://schemas.openxmlformats.org/officeDocument/2006/extended-properties\"><Application>JSON to Excel Converter</Application></Properties>";
    static string CoreProps() => "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\"><dc:title xmlns:dc=\"http://purl.org/dc/elements/1.1/\">JSON Export</dc:title></cp:coreProperties>";
}
